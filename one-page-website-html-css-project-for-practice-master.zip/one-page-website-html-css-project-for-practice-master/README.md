# One page Portfolio Website (HTML CSS Project for Ppractice)
![Watch Now](./img/Design.jpg)
## Watch The Complete Tutorial ![YouTube Video Views](https://img.shields.io/youtube/views/ZFQkb26UD1Y?style=social) : https://youtu.be/ZFQkb26UD1Y   


This project is for html &amp; css practice. We made this for youtube tutorial purpose.
<b>coded by [Shaif Arfan](https://github.com/shaifarfan)</b>


## Similar Projects/turorials

 - [Amy's Portfolio - (html, css project)](https://github.com/ShaifArfan/AMYs-Portfolio)
 - [Ayans's Profolio - (react.js project)](https://github.com/ShaifArfan/AYANs-portfolio)
  

### 👍 HAVE FUN 👍
Thanks, Arfan


